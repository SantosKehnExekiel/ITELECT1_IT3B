package com.example.schoolmanagementapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class GradeFragment extends Fragment {

    private String userRole;
    private String userId;

    public GradeFragment(String userRole, String userId) {
        this.userRole = userRole;
        this.userId = userId;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_placeholder, container, false);
        TextView tv = view.findViewById(R.id.tvPlaceholder);
        tv.setText("Grade/Grading Management for " + userRole.toUpperCase());
        return view;
    }
}