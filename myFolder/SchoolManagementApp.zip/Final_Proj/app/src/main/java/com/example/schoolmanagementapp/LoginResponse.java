package com.example.schoolmanagementapp;

public class LoginResponse {
    private String status;
    private String message;
    private String role;
    private User user_data;

    public String getStatus() { return status; }

    public String getMessage() { return message; }


    public String getRole() { return role; }
    public User getUserData() { return user_data; }
}