package com.example.schoolmanagementapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginActivity extends AppCompatActivity {

    private EditText etCredential, etPassword;
    private String role;

    private static final String BASE_URL = "http://192.168.1.1/android_api/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        role = getIntent().getStringExtra("ROLE");

        TextView tvTitle = findViewById(R.id.tvLoginTitle);
        tvTitle.setText(role.toUpperCase() + " Login");

        etCredential = findViewById(R.id.etCredential);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);

        if (role.equals("teacher")) {
            etCredential.setHint("Email (or 'admin' for Admin login)");
        } else if (role.equals("student")) {
            etCredential.setHint("Username");
        }

        btnLogin.setOnClickListener(v -> attemptLogin());
    }

    private void attemptLogin() {
        String credential = etCredential.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (credential.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter all fields.", Toast.LENGTH_SHORT).show();
            return;
        }

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService apiService = retrofit.create(ApiService.class);

        Map<String, String> loginData = new HashMap<>();
        loginData.put("credential", credential);
        loginData.put("password", password);
        loginData.put("role", role);

        apiService.loginUser(loginData).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    LoginResponse loginResponse = response.body();

                    if (loginResponse.getStatus().equals("success")) {
                        User user = loginResponse.getUserData();

                        Intent intent = new Intent(LoginActivity.this, AppBaseActivity.class);
                        intent.putExtra("USER_ROLE", loginResponse.getRole());
                        intent.putExtra("FULL_NAME", user.getFullName());

                        if (loginResponse.getRole().equals("teacher")) {
                            intent.putExtra("USER_ID", String.valueOf(user.getTeacher_id()));
                            intent.putExtra("ID_NUM", user.getID());
                        } else if (loginResponse.getRole().equals("student")) {
                            intent.putExtra("USER_ID", String.valueOf(user.getStudent_id()));
                            intent.putExtra("ID_NUM", user.getID());
                        } else {
                            intent.putExtra("USER_ID", "1");
                            intent.putExtra("ID_NUM", "ADMIN");
                        }

                        startActivity(intent);
                        finish();

                    } else {
                        Toast.makeText(LoginActivity.this, "Login Failed: " + loginResponse.getMessage(), Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Server Error. Code: " + response.code(), Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Log.e("API_CALL", "Error: " + t.getMessage());
                Toast.makeText(LoginActivity.this, "Network Error: Could not connect to API. Check XAMPP/IP.", Toast.LENGTH_LONG).show();
            }
        });
    }
}