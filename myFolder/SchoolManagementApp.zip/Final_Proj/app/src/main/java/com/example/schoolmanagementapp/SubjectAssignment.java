package com.example.schoolmanagementapp;

public class SubjectAssignment {
    private String subject_name;
    private String section_name;
    private int assignment_id;

    public String getSubject_name() { return subject_name; }
    public String getSection_name() { return section_name; }
    public int getAssignment_id() { return assignment_id; }
}