package com.example.schoolmanagementapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class HomeFragment extends Fragment {

    private String userRole;
    private String userId;
    private RecyclerView recyclerView;

    private static final String BASE_URL = "http://192.168.1.XX/android_api/";

    public HomeFragment(String userRole, String userId) {
        this.userRole = userRole;
        this.userId = userId;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = view.findViewById(R.id.recyclerViewSubjects);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        fetchSubjects();

        return view;
    }

    private void fetchSubjects() {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiService apiService = retrofit.create(ApiService.class);

        Map<String, String> data = new HashMap<>();
        data.put("role", userRole);
        data.put("user_id", userId);

        apiService.getSubjects(data).enqueue(new Callback<List<SubjectAssignment>>() {
            @Override
            public void onResponse(Call<List<SubjectAssignment>> call, Response<List<SubjectAssignment>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<SubjectAssignment> subjects = response.body();
                    SubjectAdapter adapter = new SubjectAdapter(subjects);
                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(getContext(), "Failed to load subjects: " + response.code(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<SubjectAssignment>> call, Throwable t) {
                Toast.makeText(getContext(), "Network Error: Check XAMPP/IP Address", Toast.LENGTH_LONG).show();
            }
        });
    }
}