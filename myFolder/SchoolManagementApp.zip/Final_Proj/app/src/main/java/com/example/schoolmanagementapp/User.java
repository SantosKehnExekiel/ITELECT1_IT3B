package com.example.schoolmanagementapp;

public class User {
    private String teacher_fname;
    private String teacher_lname;
    private int teacher_id;
    private String teacher_id_num;
    private String email;

    private String student_fname;
    private String student_lname;
    private int student_id;
    private String student_id_num;
    private String username;

    public String getFullName() {
        if (teacher_fname != null) {
            return teacher_fname + " " + teacher_lname;
        } else if (student_fname != null) {
            return student_fname + " " + student_lname;
        }
        return "Admin";
    }

    public String getID() {
        if (teacher_id_num != null) {
            return teacher_id_num;
        } else if (student_id_num != null) {
            return student_id_num;
        }
        return "";
    }

    public int getTeacher_id() { return teacher_id; }
    public int getStudent_id() { return student_id; }
}