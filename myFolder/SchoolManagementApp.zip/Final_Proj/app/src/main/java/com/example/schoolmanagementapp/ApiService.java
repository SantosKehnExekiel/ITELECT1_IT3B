package com.example.schoolmanagementapp;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;
import java.util.List;
import java.util.Map;

public interface ApiService {
    @POST("login.php")
    Call<LoginResponse> loginUser(@Body Map<String, String> body);

    @POST("get_subjects.php")
    Call<List<SubjectAssignment>> getSubjects(@Body Map<String, String> body);
}